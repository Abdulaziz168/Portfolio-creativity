from django.contrib import admin
from Daryo.models import Category, BlogPosts


admin.site.register(Category)
admin.site.register(BlogPosts)

