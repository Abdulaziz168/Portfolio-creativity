from django.db import models


class Category(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class BlogPosts(models.Model):
    title = models.CharField(max_length=200)
    body = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True)
    categories = models.ManyToManyField('Category', related_name='blog_posts')
    image1 = models.ImageField(upload_to='media/images', blank=True)
    image2 = models.ImageField(upload_to='media/images', blank=True)
    image3 = models.ImageField(upload_to='media/images', blank=True)
    image4 = models.ImageField(upload_to='media/images', blank=True)
    url = models.URLField(blank=True, null=True)
    video = models.FileField(upload_to='media/videos/',default='1')

    def __str__(self):
        return self.title
