from django.shortcuts import render,HttpResponse
from .models import BlogPosts,Category



def send_data_to_base(request):
    category_list = Category.objects.all()
    context ={'category_list':category_list}
    return render(request,'base.html',context)

def blogposts_index(request):
    posts = BlogPosts.objects.all().order_by('created_at')
    category_list = Category.objects.all()
    context = {'posts': posts,'category_list':category_list}
    return render(request, 'blogpost/blogpost_index.html', context)


def blogposts_category(request, category):
    posts = BlogPosts.objects.filter(
        categories__name__contains=category
    ).order_by(
        'created_at'
    )
    context = {
        "category": category,
        "posts": posts
    }
    return render(request, "blogpost/blog_category.html", context)


def blogpost_details(request, pk):
    post = BlogPosts.objects.get(pk=pk)
    context = {'post': post}
    return render(request, 'blogpost/blogpost_details.html', context)

def mahalliy(request):
    return render(request,'blogpost/mahalliy.html')