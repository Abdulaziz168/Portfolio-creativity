from django.urls import path
from . import views

urlpatterns = [
        path('', views.blogposts_index, name="blogposts_index"),
        path("<int:pk>/", views.blogpost_details, name='blogpost_details'),
        path("<category>/", views.blogposts_category, name="blogposts_category"),
]
